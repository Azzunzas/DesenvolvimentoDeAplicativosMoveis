package com.example.atividadeavaliativa

class Produtos (
    var nome : String,
    var categoria : String,
    var preco: String,
    var quantEstoque : String
){
    init {
        if (nome.isEmpty()){
            nome = "nome nao informado"
        }
        if (categoria.isEmpty()){
            categoria = "categoria nao informada"
        }
        if (preco.isEmpty()){
            preco = "preco nao informado"
        }
        if(quantEstoque.isEmpty()){
            quantEstoque = "quantidade de estoque nao informada"
        }
    }
    override fun toString(): String{
        return "Produto ( nome = $nome, categoria = $categoria, preco = $preco, quantEstoque = $quantEstoque)"
    }
}







