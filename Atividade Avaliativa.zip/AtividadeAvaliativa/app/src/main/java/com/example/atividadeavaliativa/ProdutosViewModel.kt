package com.example.atividadeavaliativa

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ProdutosViewModel : ViewModel(){
    //liveData observa a mudanca na lista dos produtos
    val produtos = MutableLiveData<List<Produtos>>(emptyList())

    fun addProduto(produto: Produtos){
        // atualiza a lista de produtos com um novo produto
        produtos.value = produtos.value?.plus(produto)
    }
}