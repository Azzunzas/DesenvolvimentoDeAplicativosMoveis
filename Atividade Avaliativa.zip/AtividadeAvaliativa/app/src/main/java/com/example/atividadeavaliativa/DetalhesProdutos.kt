package com.example.atividadeavaliativa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson

class DetalhesProduto : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Receber o produto como JSON e deserializá-lo
            val produtoJson = intent.getStringExtra("produto")
            val produto = Gson().fromJson(produtoJson, Produtos::class.java)

            LayoutDetalhesProduto(produto) {
                finish() // Volta para a tela anterior (lista de produtos)
            }
        }
    }
}

@Composable
fun LayoutDetalhesProduto(produto: Produtos, onVoltarClick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Nome: ${produto.nome}", fontSize = 22.sp)
        Text(text = "Categoria: ${produto.categoria}", fontSize = 18.sp)
        Text(text = "Preço: R$ ${produto.preco}", fontSize = 18.sp)
        Text(text = "Quantidade: ${produto.quantEstoque} Unidades", fontSize = 18.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = onVoltarClick) {
            Text(text = "Voltar")
        }
    }
}
