package com.example.atividadeavaliativa

import android.content.Intent
import android.os.Bundle
import android.text.Layout
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import com.example.atividadeavaliativa.ui.theme.AtividadeAvaliativaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BotaoTrocaDeTela()
        }
    }
}

@Composable
fun BotaoTrocaDeTela() {
    val context = LocalContext.current
    Column (modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {

        Button(onClick = {
            // Intent para abrir a SegundaActivity
            val intent = Intent(context, CadastroDeProduto::class.java)
            context.startActivity(intent)
        }) {
            Text("Abrir Cadastro de Produto")
        }
        Button(onClick = {
            // Intent para abrir a SegundaActivity
            val intent = Intent(context, ListaDeProdutos::class.java)
            context.startActivity(intent)
        }) {
            Text("Abrir Lista de Produto")
        }
    }
}


