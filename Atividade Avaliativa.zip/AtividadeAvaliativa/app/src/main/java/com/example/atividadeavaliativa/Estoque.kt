package com.example.atividadeavaliativa

class Estoque {
    companion object {
        private val produtos = mutableListOf<Produtos>()

        fun adicionarProduto(produto: Produtos) {
            produtos.add(produto)
        }

        fun calcularValorTotalEstoque(): Double {
            return produtos.sumOf { it.preco.toDouble() * it.quantEstoque.toInt() }
        }

        fun obterProdutos(): List<Produtos> {
            return produtos
        }
    }
}
