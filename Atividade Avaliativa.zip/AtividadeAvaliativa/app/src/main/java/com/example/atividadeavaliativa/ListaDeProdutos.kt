package com.example.atividadeavaliativa

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson // Biblioteca para serializar o objeto Produto

class ListaDeProdutos : ComponentActivity() {
    private val viewModel: ProdutosViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LayoutListaProdutos(viewModel) { produto ->
                val intent = Intent(this, DetalhesProduto::class.java)

                // Usando Gson para converter o objeto Produto para uma string JSON
                val produtoJson = Gson().toJson(produto)
                intent.putExtra("produto", produtoJson)

                startActivity(intent)
            }
        }
    }
}

@Composable
fun LayoutListaProdutos(viewModel: ProdutosViewModel, onProdutoSelecionado: (Produtos) -> Unit) {
    val produtos = viewModel.produtos.value ?: emptyList()
    val context = LocalContext.current

    Column(modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 32.dp), // Padding no topo e nas laterais
        verticalArrangement = Arrangement.Top) {

        Text(text = "Lista de Produtos", fontSize = 22.sp)

        if (produtos.isEmpty()) {
            Text(text = "Nenhum produto cadastrado ainda!", modifier = Modifier.padding(top = 16.dp))
        } else {
            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                items(produtos) { produto ->
                    ProdutoItem(produto) {
                        onProdutoSelecionado(produto)
                    }
                }
            }
        }

        Button(modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp)
            .height(70.dp),
            onClick = {
                val intent = Intent(context, EstatisticasActivity::class.java)
                context.startActivity(intent)
            }) {
            Text("Estatísticas")
        }
    }
}


@Composable
fun ProdutoItem(produto: Produtos, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = "${produto.nome} (${produto.quantEstoque} Unidades)")
        Button(onClick = onClick) {
            Text("Detalhes")
        }
    }
}
