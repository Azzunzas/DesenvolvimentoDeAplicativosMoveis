package com.example.atividadeavaliativa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class EstatisticasActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LayoutEstatisticas()
        }
    }
}

@Composable
fun LayoutEstatisticas() {
    val valorTotalEstoque = Estoque.calcularValorTotalEstoque()
    val quantidadeTotalProdutos = Estoque.obterProdutos().sumOf { it.quantEstoque.toInt() }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Estatísticas do Estoque", fontSize = 22.sp)

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Valor Total do Estoque: R$ ${String.format("%.2f", valorTotalEstoque)}", fontSize = 18.sp)
        Text(text = "Quantidade Total de Produtos: $quantidadeTotalProdutos", fontSize = 18.sp)
    }
}
