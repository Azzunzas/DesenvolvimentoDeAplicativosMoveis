package com.example.atividadeavaliativa

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class CadastroDeProduto : ComponentActivity() {
    private val viewModel: ProdutosViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LayoutCadastroProduto(viewModel)
        }
    }
}

@Composable
fun LayoutCadastroProduto(viewModel: ProdutosViewModel) {
    var nome by remember { mutableStateOf("") }
    var categoria by remember { mutableStateOf("") }
    var preco by remember { mutableStateOf("") }
    var quantEstoque by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Cadastro de Produtos", fontSize = 22.sp)

        TextField(
            value = nome,
            onValueChange = { nome = it },
            label = { Text("Digite o nome do produto") },
            modifier = Modifier.fillMaxWidth()
        )
        TextField(
            value = categoria,
            onValueChange = { categoria = it },
            label = { Text("Digite a categoria do produto") },
            modifier = Modifier.fillMaxWidth()
        )
        TextField(
            value = preco,
            onValueChange = { preco = it },
            label = { Text("Digite o preço do produto") },
            modifier = Modifier.fillMaxWidth()
        )
        TextField(
            value = quantEstoque,
            onValueChange = { quantEstoque = it },
            label = { Text("Digite a quantidade do produto") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(modifier = Modifier
            .fillMaxWidth()
            .height(70.dp),
            onClick = {
                try {
                    val precoDouble = preco.toDoubleOrNull()
                    val quantEstoqueInt = quantEstoque.toIntOrNull()
                    Log.d("CadastroProduto", "Nome: $nome, Categoria: $categoria, Preço: $precoDouble, Quantidade: $quantEstoqueInt")

                    // Verificação se os campos estão preenchidos corretamente
                    if (nome.isNotBlank() && categoria.isNotBlank() && precoDouble != null && quantEstoqueInt != null) {
                        if (precoDouble < 0) {
                            Toast.makeText(context, "O preço deve ser maior ou igual a zero!", Toast.LENGTH_SHORT).show()
                        } else if (quantEstoqueInt < 1) {
                            Toast.makeText(context, "A quantidade deve ser maior ou igual a 1!", Toast.LENGTH_SHORT).show()
                        } else {
                            val novoProduto = Produtos(nome, categoria, precoDouble.toString(), quantEstoqueInt.toString())
                            Estoque.adicionarProduto(novoProduto)
                            viewModel.addProduto(novoProduto)

                            // Limpar os campos após o cadastro
                            nome = ""
                            categoria = ""
                            preco = ""
                            quantEstoque = ""

                            Toast.makeText(context, "Produto cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(context, "Preencha todos os campos corretamente! Preço e quantidade devem ser numéricos.", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Log.e("CadastroProduto", "Erro ao cadastrar produto", e)
                    Toast.makeText(context, "Ocorreu um erro ao cadastrar o produto. Tente novamente.", Toast.LENGTH_SHORT).show()
                }
            }) {
            Text(text = "Cadastrar Produto")
        }

        Button(modifier = Modifier
            .fillMaxWidth()
            .height(70.dp), onClick = {
            val intent = Intent(context, ListaDeProdutos::class.java)
            context.startActivity(intent)
        }) {
            Text("Ir para Lista de Produtos")
        }
    }
}
