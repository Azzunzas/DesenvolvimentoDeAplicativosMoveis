package com.example.atividadenova

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            layoutJogador()
        }
    }
}

data class Jogador(
    var nome: String = "",
    var bonus: Int = 0,
    var level: Int = 1,
    var mod: Int = 0
) {
    val power: Int
        get() = level + bonus + mod
}

@Composable
fun layoutJogador() {
    var jogadores by remember { mutableStateOf(mutableListOf(Jogador())) }
    var jogadorAtual by remember { mutableStateOf(0) }
    var quantidadeJogadores by remember { mutableStateOf(1) }

    val context = LocalContext.current

    // Função para validar a quantidade de jogadores
    fun validarQuantidadeJogadores(novaQuantidade: Int) {
        if (novaQuantidade > 6) {
            Toast.makeText(context, "Já temos 6 jogadores!", Toast.LENGTH_SHORT).show()
        } else if (novaQuantidade < 1) {
            Toast.makeText(context, "O mínimo é 1 jogador!", Toast.LENGTH_SHORT).show()
        } else {
            if (novaQuantidade > quantidadeJogadores) {
                // Adiciona novos jogadores mantendo os antigos
                jogadores.addAll(List(novaQuantidade - quantidadeJogadores) { Jogador() })
            } else {
                // Remove jogadores excedentes
                jogadores = jogadores.subList(0, novaQuantidade)
            }
            quantidadeJogadores = novaQuantidade
        }
    }

    val jogador = jogadores[jogadorAtual]

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxSize().padding(16.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = { validarQuantidadeJogadores(quantidadeJogadores - 1) }) {
                Text(" - ")
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text("Jogadores: $quantidadeJogadores", fontSize = 20.sp)
            Spacer(modifier = Modifier.width(10.dp))
            Button(onClick = { validarQuantidadeJogadores(quantidadeJogadores + 1) }) {
                Text(" + ")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("Jogador ${jogadorAtual + 1}:", fontSize = 22.sp)
        TextField(
            value = jogador.nome,
            onValueChange = { novoNome ->
                jogadores = jogadores.toMutableList().also { it[jogadorAtual] = it[jogadorAtual].copy(nome = novoNome) }
            },
            label = { Text("Nome do Jogador") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = { if (jogador.level > 1) jogadores = jogadores.toMutableList().also { it[jogadorAtual] = it[jogadorAtual].copy(level = it[jogadorAtual].level - 1) } }) {
                Text(" - ")
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text("LEVEL: ${jogador.level}", fontSize = 20.sp)
            Spacer(modifier = Modifier.width(10.dp))
            Button(onClick = { if (jogador.level < 10) jogadores = jogadores.toMutableList().also { it[jogadorAtual] = it[jogadorAtual].copy(level = it[jogadorAtual].level + 1) } }) {
                Text(" + ")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("POWER: ${jogador.power}", fontSize = 20.sp)

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = { jogadores = jogadores.toMutableList().also { it[jogadorAtual] = it[jogadorAtual].copy(bonus = it[jogadorAtual].bonus - 1) } }) {
                Text(" - ")
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text("EQUIPAMENTO: ${jogador.bonus}", fontSize = 20.sp)
            Spacer(modifier = Modifier.width(10.dp))
            Button(onClick = { jogadores = jogadores.toMutableList().also { it[jogadorAtual] = it[jogadorAtual].copy(bonus = it[jogadorAtual].bonus + 1) } }) {
                Text(" + ")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = { jogadores = jogadores.toMutableList().also { it[jogadorAtual] = it[jogadorAtual].copy(mod = it[jogadorAtual].mod - 1) } }) {
                Text(" - ")
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text("MODIFICADORES: ${jogador.mod}", fontSize = 20.sp)
            Spacer(modifier = Modifier.width(10.dp))
            Button(onClick = { jogadores = jogadores.toMutableList().also { it[jogadorAtual] = it[jogadorAtual].copy(mod = it[jogadorAtual].mod + 1) } }) {
                Text(" + ")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = { if (jogadorAtual > 0) jogadorAtual-- }) {
                Text("Jogador Anterior")
            }
            Spacer(modifier = Modifier.width(20.dp))
            Button(onClick = { if (jogadorAtual < quantidadeJogadores - 1) jogadorAtual++ }) {
                Text("Próximo Jogador")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewLayoutJogador() {
    layoutJogador()
}
